<?php
$password = "branch2@123";
echo password_hash($password, PASSWORD_DEFAULT);
?>
