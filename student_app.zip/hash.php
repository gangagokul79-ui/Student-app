<?php
echo password_hash("branch2@123", PASSWORD_DEFAULT);
